import os
import time
os.environ['TF_CPP_MIN_LOG_LEVEL']='1'

from __future__ import print_function

import tensorflow as tf
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten
from tensorflow.keras.optimizers import Adam, SGD
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt
import numpy as np


num_classes = 10
input = (32, 32, 3)

#load (first download if necessary) the CIFAR10 dataset
# data is already split in train and test datasets
(x_train, y_train), (x_test, y_test) = cifar10.load_data()

# x_train = np.expand_dims(x_train, axis=-1)
# x_test = np.expand_dims(x_test, axis=-1)

#Convert to float
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')

#Normalize inputs from [0; 255] to [0; 1]
x_train = x_train / 255
x_test = x_test / 255

y_train = tf.keras.utils.to_categorical(y_train)
y_test = tf.keras.utils.to_categorical(y_test)


# Transfer learning

from tensorflow.keras.applications import vgg16
from tensorflow.keras.applications.resnet50 import ResNet50

x_train, x_val, y_train, y_val = train_test_split(x_train, y_train, test_size=0.2, random_state=42)


train_datagen = ImageDataGenerator(
    rotation_range = 10,
    zoom_range = 0.1, 
    width_shift_range=0.2,  
    height_shift_range=0.2,  
    horizontal_flip=True,  
    vertical_flip=False) 

valid_datagen = ImageDataGenerator(
    rotation_range = 10, 
    zoom_range = 0.1, 
    width_shift_range=0.2,  
    height_shift_range=0.2,  
    horizontal_flip=True,  
    vertical_flip=False) 

train_datagen.fit(x_train)
valid_datagen.fit(x_val)


model = vgg16.VGG16(input_shape = input,
                    include_top = False, 
                    weights = 'imagenet')

# for layer in model.layers:
#   layer.trainable = False

x = Flatten()(model.output)
x = Dense(256, activation='relu')(x)
x = Dropout(0.4)(x)
x = Dense(128, activation='relu')(x)
x = Dropout(0.2)(x)
x = Dense(64, activation='relu')(x)
x = Dropout(0.1)(x)
predictions = Dense(10, activation='softmax')(x)
full_model = tf.keras.models.Model(inputs=model.input, outputs=predictions)
full_model.summary()


opt = SGD(learning_rate=0.001, momentum=0.9)
# opt = Adam(learning_rate=0.01)

full_model.compile(optimizer=opt, loss='categorical_crossentropy', metrics=['accuracy'])
history = full_model.fit_generator(train_datagen.flow(x_train, y_train, batch_size=64),
                                   steps_per_epoch=len(x_train) / 64, epochs=100, validation_data=valid_datagen.flow(x_val, y_val, batch_size = 64))




plt.figure(figsize = (10,10))

print(history.history.keys())
plt.subplot(221)
plt.plot(history.history['accuracy'], label='Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation accuracy')
plt.title('Accuracy Rand')
plt.ylabel('')
plt.xlabel('Epoch')
plt.legend(loc="upper left")

plt.subplot(222)
plt.plot(history.history['loss'], label='Loss')
plt.plot(history.history['val_loss'], label='Validation loss')
plt.title('Sparse Categorical CrossEntropy')
plt.ylabel('')
plt.xlabel('Epoch')
plt.legend(loc="upper left")


test_loss, test_accuracy = full_model.evaluate(x_test, y_test)
print(f"Evaluation result on Test Data : Loss = {test_loss}, accuracy = {test_accuracy}")
