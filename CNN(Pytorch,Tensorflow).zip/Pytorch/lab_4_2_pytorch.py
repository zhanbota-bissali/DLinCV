from __future__ import print_function

#The two following lines allow to reduce tensorflow verbosity
import os
import time
os.environ['TF_CPP_MIN_LOG_LEVEL']='1' # '0' for DEBUG=all [default], '1' to filter INFO msgs, '2' to filter WARNING msgs, '3' to filter all msgs

import torch
from torch.utils.data import TensorDataset, DataLoader
from torch import nn

import tensorflow
from tensorflow.keras.datasets import cifar10

import matplotlib.pyplot as plt
import numpy as np

##Uncomment the following two lines if you get CUDNN_STATUS_INTERNAL_ERROR initialization errors.
## (it happens on RTX 2060 on room 104/moneo or room 204/lautrec) 
# physical_devices = tf.config.experimental.list_physical_devices('GPU')
# tf.config.experimental.set_memory_growth(physical_devices[0], True)

(x_train, y_train), (x_test, y_test) = cifar10.load_data()

#Convert to float and labels to int
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
y_train = y_train.astype('int')
y_test = y_test.astype('int')


#Normalize inputs from [0; 255] to [0; 1]
x_train = x_train / 255
x_test = x_test / 255

print('x_train.shape=', x_train.shape)
print('x_test.shape=', x_test.shape)

# Plot some sample iamges

class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer',
               'dog', 'frog', 'horse', 'ship', 'truck']

plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(x_train[i])
    # The CIFAR labels happen to be arrays,
    # which is why you need the extra index
    plt.xlabel(class_names[y_train[i][0]])
plt.show()

num_classes = 10
input_shape = (32, 32, 3)

batch_size = 128

x_train_tensor = torch.Tensor(x_train).permute(0,3,1,2)
y_train_tensor = torch.Tensor(y_train).type(torch.LongTensor)
y_train_tensor = torch.squeeze(y_train_tensor)
x_test_tensor = torch.Tensor(x_test).permute(0,3,1,2)
y_test_tensor = torch.Tensor(y_test).type(torch.LongTensor)
y_test_tensor = torch.squeeze(y_test_tensor)

train_dataset = TensorDataset(x_train_tensor, y_train_tensor)
test_dataset = TensorDataset(x_test_tensor, y_test_tensor)

train_dataloader = DataLoader(train_dataset, batch_size=batch_size)
test_dataloader = DataLoader(test_dataset, batch_size=batch_size)


#Let start our work: creating a convolutional neural network

#####TO COMPLETE


# Get cpu or gpu device for training.
device = "cuda" if torch.cuda.is_available() else "cpu"
print("Using {} device".format(device))

# Define model
class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()

        self.cnn_layers = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=32, kernel_size=(3, 3),
                  stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(in_channels=32, out_channels=32, kernel_size=(3, 3),
                  stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(2, 2), stride=2),
            nn.Dropout2d(p=0.25),
            
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(3, 3),
                  stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(in_channels=64, out_channels=64, kernel_size=(3, 3),
                  stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(2, 2), stride=2),
            nn.Dropout2d(p=0.35),

            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=(3, 3),
                  stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=(3, 3),
                  stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=(2, 2), stride=2),
            nn.Dropout2d(p=0.45),

            nn.Flatten(),
            nn.Linear(2048, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 10),
        )

    def forward(self, x):
        return self.cnn_layers(x)

model = NeuralNetwork().to(device)

learning_rate = 0.001
epochs = 100
loss_fn = nn.CrossEntropyLoss()
# optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
# optimizer = torch.optim.Adagrad(model.parameters(), lr=learning_rate)
# optimizer = torch.optim.RMSprop(model.parameters(), lr=learning_rate)


def train(dataloader, model, loss_fn, optimizer):
    size = len(dataloader.dataset)
    model.train()

    train_loss = 0
    correct = 0

    for batch, (X, y) in enumerate(dataloader):
        X, y = X.to(device), y.to(device)

        pred = model(X)
        loss = loss_fn(pred, y)

        train_loss += loss.item() * X.size(0)
        correct += (pred.argmax(1) == y).type(torch.float).sum().item()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # if batch % 100 == 0:
        #     loss, current = loss.item(), batch * len(X)
        #     print(f"loss: {loss:>7f}  [{current:>5d}/{size:>5d}]")

    train_loss /= len(dataloader.dataset)
    accuracy = correct / len(dataloader.dataset)

    return train_loss, accuracy

def test(dataloader, model, loss_fn):
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for X, y in dataloader:
            X, y = X.to(device), y.to(device)

            pred = model(X)
            test_loss += loss_fn(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()

    test_loss /= num_batches
    accuracy = correct / len(dataloader.dataset)

    return test_loss, accuracy

train_losses = []
train_accuracies = []
test_losses = []
test_accuracies = []

for t in range(epochs):
    print(f"Epoch {t+1}\n-------------------------------")
    train_loss, train_accuracy = train(train_dataloader, model, loss_fn, optimizer)
    test_loss, test_accuracy = test(test_dataloader, model, loss_fn)

    print(f"Train Error: Accuracy: {(100*train_accuracy):>0.1f}%, Avg loss: {train_loss:>8f}")
    print(f"Test Error: Accuracy: {(100*test_accuracy):>0.1f}%, Avg loss: {test_loss:>8f}")
    train_losses.append(train_loss)
    train_accuracies.append(train_accuracy)
    test_losses.append(test_loss)
    test_accuracies.append(test_accuracy)


import matplotlib.pyplot as plt

plt.figure(figsize = (10,10))

plt.subplot(221)
plt.plot(train_accuracies, label='Accuracy')
plt.plot(test_accuracies, label='Validation accuracy')
plt.title('Accuracy Rand')
plt.ylabel('')
plt.xlabel('Epoch')
plt.legend(loc="upper left")

plt.subplot(222)
plt.plot(train_losses, label='Loss')
plt.plot(test_losses, label='Validation loss')
plt.title('Sparse Categorical CrossEntropy')
plt.ylabel('')
plt.xlabel('Epoch')
plt.legend(loc="upper left")
