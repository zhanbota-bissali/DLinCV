from __future__ import print_function
import numpy as np

#In this first part, we just prepare our data (mnist) 
#for training and testing

#import keras
from tensorflow.keras.datasets import mnist
(X_train, y_train), (X_test, y_test) = mnist.load_data()


num_pixels = X_train.shape[1] * X_train.shape[2]
X_train = X_train.reshape(X_train.shape[0], num_pixels).T
X_test = X_test.reshape(X_test.shape[0], num_pixels).T
y_train = y_train.reshape(y_train.shape[0], 1)
y_test = y_test.reshape(y_test.shape[0], 1)
X_train = X_train.astype('float32')
X_test = X_test.astype('float32')
y_train = y_train.astype('float32')
y_test = y_test.astype('float32')
X_train  = X_train / 255
X_test  = X_test / 255


#We want to have a binary classification: digit 0 is classified 1 and 
#all the other digits are classified 0

y_new = np.zeros(y_train.shape)
y_new[np.where(y_train==0.0)[0]] = 1
y_train = y_new

y_new = np.zeros(y_test.shape)
y_new[np.where(y_test==0.0)[0]] = 1
y_test = y_new


y_train = y_train.T
y_test = y_test.T

m = X_train.shape[1] #number of examples

#Now, we shuffle the training set
np.random.seed(138)
shuffle_index = np.random.permutation(m)
X_train, y_train = X_train[:,shuffle_index], y_train[:,shuffle_index]


# #Display one image and corresponding label 
# import matplotlib
# import matplotlib.pyplot as plt
# i = 3
# print('y[{}]={}'.format(i, y_train[:,i]))
# plt.imshow(X_train[:,i].reshape(28,28), cmap = matplotlib.cm.binary)
# plt.axis("off")
# plt.show()


def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def deriv_sigmoid(x):
    return (np.exp(-x)) / ((np.exp(-x) + 1)**2)

def forward(x, w, b):
    y = sigmoid(np.sum(x.T * w, axis=1) + b)
    return y

def loss(y, y_pred):
    """
    y: Targets
    y_pred: Predictions
    """
    # n = y_est.shape[0]
    # return -np.sum(y * np.log(y_pred)) / n

    return -1/m * np.sum(y * np.log(y_pred) + (1 - y) * np.log(1 - y_pred))

def deriv_loss(y, y_pred):
    return -y/y_pred + (1-y) / (1-y_pred)

def accuracy(y, y_pred):
    y_pred = np.where(y_pred > 0.5, 1, 0)
    return np.count_nonzero(y_pred == y) / y.size

X = X_train
Y = y_train
X_val = X_test
Y_val = y_test
lr = 0.5

train_loss = []
val_loss = []
train_accuracy = []
val_accuracy = []

input_width = X.shape[0]
hidden_width = 64
output_width = Y.shape[0]

W1 = np.random.randn(hidden_width, input_width)*0.5
b1 = np.zeros((hidden_width, 1))
W2 = np.random.randn(output_width, hidden_width)*0.5
b2 = np.zeros((output_width, 1))

for i in range(100):

    # Forward

    Z1 = np.dot(W1, X) + b1
    A1 = sigmoid(Z1)
    Z2 = np.dot(W2, A1) + b2
    A2 = sigmoid(Z2)

    # Calculate cost and accuracy
    train_loss.append(loss(Y, A2))
    train_accuracy.append(accuracy(Y, A2))
    print("Train loss:", train_loss[-1])
    print("Train accuracy:", train_accuracy[-1])

    # Calculate validations scores
    Z1_val = np.dot(W1, X_val) + b1
    A1_val = sigmoid(Z1_val)
    Z2_val = np.dot(W2, A1_val) + b2
    A2_val = sigmoid(Z2_val)
    val_loss.append(loss(Y_val, A2_val))
    val_accuracy.append(accuracy(Y_val, A2_val))
    print("Validation loss:", val_loss[-1])
    print("Validation accuracy:", val_accuracy[-1])

    # Backprop

    m = X.shape[1]

    derivZ2 = A2-Y
    derivW2 = (1/m) * np.matmul(derivZ2, A1.T)
    derivb2 = (1/m) * np.sum(derivZ2, axis=1, keepdims=True)
    derivZ1 = np.multiply(np.matmul(W2.T, derivZ2), deriv_sigmoid(A1))
    derivW1 = (1/m) * np.matmul(derivZ1, X.T)
    derivb1 = (1/m) * np.sum(derivZ1, axis=1, keepdims=True)

    W1 -= lr * derivW1
    b1 -= lr * derivb1
    W2 -= lr * derivW2
    b2 -= lr * derivb2


import matplotlib.pyplot as plt

fig, ax = plt.subplots()
ax.plot(train_loss, c="b", label="train")
ax.plot(val_loss, c="r", label="validation")
ax.set_xlabel('epoch')
ax.set_ylabel('loss')
ax.legend()

fig2, ax = plt.subplots()
ax.plot(train_accuracy, c="b", label="train")
ax.plot(val_accuracy, c="r", label="validation")
ax.set_xlabel('epoch')
ax.set_ylabel('accuracy')
ax.legend()
plt.show()
